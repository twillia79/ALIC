from datetime import datetime

import eventlet
import pyodbc

from app.models import Machine, Log
from app import db, socketio


class PI_Interface:
    username = 'PIFUser'
    password = 'UserPIF'
    database = 'PI'
    server = ''
    cnxn = ''
    cursor = ''

    def __init__(self, server):
        self.server = server
        self.cnxn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + server + ';DATABASE=' + self.database + ';UID=' + self.username + ';PWD=' + self.password)
        self.cursor = self.cnxn.cursor()

    # TODO implement
    def get_machine_production_status(self):
        _prodID = self.cursor.execute(
            "SELECT WMSPalletID, TransDate, ItemID, SECMachineID FROM [PI].[dbo].[tblProdTrans] WHERE TransDate IN (SELECT MAX(TransDate) FROM [PI].[dbo].[tblProdTrans] WHERE TransID = 10 GROUP BY SECMachineID) AND TransID = 10 ORDER BY SECMachineID")
        _fetch = _prodID.fetchall()
        # print(_fetch)

        machines = Machine.query.all()
        # print(machines)

        for machine in machines:
            machine.production_number = _fetch[machine.id - 1][2]
        db.session.commit()

        machines = Machine.query.all()

        for machine in machines:
            print("Name: {name}, PRD: {PRD}, Action: {act}".format(name=machine.name, PRD=machine.production_number,
                                                                   act=machine.action.action))
        return machines

    def log_action_changes(self):
        log = Log.query.all()

        return log

    def get_production_status_thread(self):
        while True:
            self.get_machine_production_status()

            eventlet.sleep(10)


@socketio.on('update')
def update(machines):
    machine_action = Machine.query.all()
    i = 0
    for actions in machine_action:
        actions.action_id = machines[i]
        i += 1
        print("Action: {action}".format(action=actions.action_id))
    db.session.commit()

    logging = Log(
        timestamp=datetime.utcnow(),
        production_num='123456',
        action_id='1'
    )
    db.session.add(logging)
    db.session.commit()

    socketio.emit('refresh_page')



