from app import db
from app.models import Action, Machine

if not Action.query.filter_by(id=1).first():
    act = Action(id=1, action='NONE')
    db.session.add(act)
    act = Action(id=2, action='RAKE')
    db.session.add(act)
    act = Action(id=3, action='LID')
    db.session.add(act)
    act = Action(id=4, action='BOTH')
    db.session.add(act)
    db.session.commit()

if not Machine.query.filter_by(id=1).first():
    mach = Machine(id=1, name="Husky 1", production_number=0, action_id=3)
    db.session.add(mach)
    mach = Machine(id=2, name="Husky 2", production_number=0, action_id=4)
    db.session.add(mach)
    mach = Machine(id=3, name="Husky 3", production_number=0, action_id=1)
    db.session.add(mach)
    mach = Machine(id=4, name="Husky 4", production_number=0, action_id=1)
    db.session.add(mach)
    mach = Machine(id=5, name="Husky 5", production_number=0, action_id=3)
    db.session.add(mach)
    mach = Machine(id=6, name="Husky 6", production_number=0, action_id=1)
    db.session.add(mach)
    mach = Machine(id=7, name="Husky 7", production_number=0, action_id=2)
    db.session.add(mach)
    mach = Machine(id=8, name="Husky 8", production_number=0, action_id=1)
    db.session.add(mach)
    mach = Machine(id=9, name="Husky 9", production_number=0, action_id=1)
    db.session.add(mach)
    mach = Machine(id=10, name="Husky 10", production_number=0, action_id=1)
    db.session.add(mach)
    db.session.commit()

