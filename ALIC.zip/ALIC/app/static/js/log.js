(function($) {

$(document).ready(function(){
$('#LogTable').DataTable({
    "order": [[ 1, "desc" ]]
});
})




})(jQuery);