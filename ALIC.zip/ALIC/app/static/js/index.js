(function($) {
    'use strict';

    var socket = io.connect();
    
    socket.on('connect', function () {
        socket.emit('client connected', {data: 'Client Connected'});
    });

    socket.on('disconnect', function () {
        socket.emit('client disconnected', {data: 'Client Disconnected'});
    });

    $("#update_button").click(function() {

        let machines = [];

        $("input[type ='radio']:checked").each(function(){
            const value = $(this).val();

            machines.push(value);
        });
        socket.emit('update', machines);
    });

    socket.on('refresh_page', function() {
       location.reload();
    });

})(jQuery);