from app import db
from datetime import datetime


class Action(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    action = db.Column(db.String(32), unique=True)
    machines = db.relationship('Machine', backref='action')
    log = db.relationship('Log', backref='log_action')


class Machine(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), index=True, unique=True)
    production_number = db.Column(db.String(128), index=True)
    timestamp_updated = db.Column(db.DateTime, default=datetime.utcnow())
    action_id = db.Column(db.Integer, db.ForeignKey('action.id'))
    log = db.relationship('Log', backref='data', lazy=True)


class Log(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow())
    # machine = db.Column(db.String(128), index=True, unique=True)
    production_num = db.Column(db.String(128), index=True)
    machine_id = db.Column(db.Integer, db.ForeignKey('machine.id'))
    action_id = db.Column(db.Integer, db.ForeignKey('action.id'))
