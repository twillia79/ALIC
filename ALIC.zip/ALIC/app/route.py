from flask import render_template
from app import app, socketio

from app.pi_interface import PI_Interface

boxinfo = PI_Interface('oh-dc1')


@app.route('/')
@app.route('/index.html')
def index():
    machine_info = boxinfo.get_machine_production_status()

    return render_template('index.html', machines=machine_info)


@app.route('/log.html')
def log():
    log_info = boxinfo.log_action_changes()
    return render_template('log.html', log=log_info)


@socketio.on('connect')
def connect():
    print("A client just connected")


@socketio.on('disconnect')
def disconnect():
    print("A client just disconnected")
